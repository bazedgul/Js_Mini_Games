document.body.style.background = "cyan"
function RandomLetter() {
  const Alphabets = " SGW";
  return Alphabets[Math.floor(Math.random() * Alphabets.length)]
}
let ComputerWin = 0;
let PlayerWin = 0;
let GameTie = 0;

let GamePlay = () => {
  let ComputerPlayer = RandomLetter()
  let RealPlayer = prompt("Choose Option from S , G , W")

  // Game 
  if (!RealPlayer) {
    GameTie++
    alert("Game Tie")
  }

  // Player Game Win View condition
  else if ((RealPlayer == "S" && ComputerPlayer == "G") || (RealPlayer == "G" &&
    ComputerPlayer == "W") || (RealPlayer == "S" && ComputerPlayer == "W")) {
    PlayerWin++
    alert("Real Player Wins");
  }
  // GameTie Condition
  else if ((RealPlayer == "S" && ComputerPlayer == "S") || (RealPlayer == "G" && ComputerPlayer == "G") || (RealPlayer == "W" && ComputerPlayer == "W")) {
    GameTie++
    alert("Game Tie");
  }
  //Computer Player Win Condition
  else {
    ComputerWin++
    alert("Computer Player Wins");
  }
}

let play = true;
while (play) {
  GamePlay()
  play = confirm("Do you want to Play Again ?")
}
document.write("Real Player Wins Record Are " + " (" + PlayerWin)
document.write(" ) Computer Player Wins Record Are " + " (" + ComputerWin)
document.write(" ) Game Tie Record Are " + " (" + GameTie + " )")

if (PlayerWin > ComputerWin) {
  document.write("Final Status : Player Wins The Game ")
}
else if (Player == ComputerWin) {
  document.write(" Final Status : Game Tied ")
}

else {
  document.write(" Final Status : Computer Wins ")
}


