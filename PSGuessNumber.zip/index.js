let x = Math.random() * 100;
x = Number.parseInt(x);

for(let i = 0; i<=100;i++){
  let Score = 100 - i;
  let num = prompt("Enter a Number to Guess 1 to 100 : ");
  num = Number.parseInt(num);
  if(num != x){
    console.log("Your Guess Number is Wrong, Try Again !!! ");
    if(num > x){
      console.log("Apki Guess Value is sy Choti hai ," ,num)
    }else{
      console.log("Apki Guess value is sy barhi hai ," ,num)
    }
  }
  else{
    console.log("Your Guess Number is Correct, Congrats !!!")
    console.log(i," Times for Guess & The Answers is : ", x)
    console.log("Guess Score is ", Score ,"/100")
    break
  }}


// let x = Math.random() * 100;
// x = Number.parseInt(x);

// for(let i = 0; i<=100;i++){
//   let score = 100 - i;
//   let num = prompt("Ente a Number to Guess : ");
//   num = Number.parseInt(num);
//   if(num != x){
//     console.log("Your Guess is Wrong, Try Again !")
//   if(num > x){
//   console.log("Guess Choti Value Karo is Number sy : ", num)
//   }else{
//     console.log("Guess Barhi Value karo is Number sy : ",num)
//   }}
//   else{
//     console.log("Your Guess is Correct, Congrats" )
//     console.log(i, " Times for Guess & the Answer is", x)
//     console.log("Guess Score is ",score ,"/100 !!!")
//   }
// }

